export default function Profile() {
  return <div style={{ padding: 24 }}>Profile page</div>;
}
