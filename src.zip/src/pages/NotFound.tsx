export default function NotFound() {
  return <div style={{ padding: 24 }}>404 — Not Found</div>;
}
