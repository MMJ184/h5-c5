export default function Team() {
  return <div style={{ padding: 24 }}>Team page</div>;
}
