export default function Home() {
  return <div style={{ padding: 24 }}>Home page</div>;
}
