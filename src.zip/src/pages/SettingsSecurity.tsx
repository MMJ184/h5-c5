export default function SettingsSecurity() {
  return <div style={{ padding: 24 }}>Settings — Security</div>;
}
