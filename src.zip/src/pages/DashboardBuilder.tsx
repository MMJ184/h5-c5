import {
  Layout,
  Button,
  Drawer,
  List,
  Card,
  Typography,
  Space,
  theme,
  Tabs,
  Modal,
  Input,
  Tag,
  Tooltip,
  Divider,
} from 'antd';
import React, { useEffect, useRef, useState } from 'react';
import RGL, { WidthProvider, Layout as RGLLayout } from 'react-grid-layout';

import 'react-grid-layout/css/styles.css';
import 'react-resizable/css/styles.css';
import './DashboardBuilder.css';

import {
  getWidgetComponentByType,
  getWidgetDefinition,
  widgetDefinitions,
} from './Dashboard/widgets/WidgetRegistry';

import type { WidgetDefinition, WidgetType } from './Dashboard/widgets/types';

import {
  AppstoreOutlined,
  CheckOutlined,
  DeleteOutlined, EditOutlined,
  LayoutOutlined,
  PlusOutlined,
  SaveOutlined
} from '@ant-design/icons';

const { Content } = Layout;
const { Text, Title } = Typography;

const ReactGridLayout = WidthProvider(RGL);

/* ---------- TYPES ---------- */

interface DashboardWidgetInstance {
  id: string;
  type: WidgetType;
}

interface DashboardData {
  id: string;
  name: string;
  widgets: DashboardWidgetInstance[];
  layout: RGLLayout[];
  createdAt: string;
}

const STORAGE_KEY = 'dashboard_builder_multi_v1';

/* ---------- WIDGET CARD ---------- */

interface WidgetCardProps {
  title: string;
  onRemove: () => void;
  children: React.ReactNode;
  isEditing: boolean;
}

const WidgetCard: React.FC<WidgetCardProps> = ({ title, onRemove, children, isEditing }) => {
  return (
    <Card
      size="small"
      className={`widget-card ${isEditing ? 'widget-card--editing' : ''}`}
      style={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        minHeight: 0,
      }}
      bodyStyle={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        minHeight: 0,
        padding: 12,
      }}
      title={
        <Space size={6}>
          <AppstoreOutlined />
          <span>{title}</span>
        </Space>
      }
      extra={
        isEditing ? (
          <Tooltip title="Remove widget">
            <Button
              type="text"
              size="small"
              icon={<DeleteOutlined />}
              className="widget-delete-btn"
              onMouseDown={(e) => e.stopPropagation()}
              onClick={(e) => {
                e.stopPropagation();
                onRemove();
              }}
            />
          </Tooltip>
        ) : null
      }
    >
      <div
        style={{
          flex: 1,
          minHeight: 0,
          overflow: 'auto',
        }}
      >
        {children}
      </div>
    </Card>
  );
};

/* ---------- MAIN COMPONENT ---------- */

const DashboardBuilder: React.FC = () => {
  const [widgets, setWidgets] = useState<DashboardWidgetInstance[]>([]);
  const [layout, setLayout] = useState<RGLLayout[]>([]);

  const [dashboards, setDashboards] = useState<DashboardData[]>([]);
  const [activeDashboardId, setActiveDashboardId] = useState<string | null>(null);

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);
  const [saveName, setSaveName] = useState('');

  const { token } = theme.useToken();
  const layoutRef = useRef<HTMLDivElement | null>(null);

  const generateId = () => `w_${Math.random().toString(36).substring(2, 9)}`;

  /* ---------- LOAD FROM LOCAL STORAGE ---------- */

  useEffect(() => {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;

    try {
      const parsed = JSON.parse(raw) as {
        dashboards?: DashboardData[];
        activeDashboardId?: string;
      };

      if (parsed.dashboards && parsed.dashboards.length > 0) {
        setDashboards(parsed.dashboards);

        const activeId =
          parsed.activeDashboardId &&
          parsed.dashboards.some((d) => d.id === parsed.activeDashboardId)
            ? parsed.activeDashboardId
            : parsed.dashboards[0].id;

        setActiveDashboardId(activeId);

        const activeDashboard =
          parsed.dashboards.find((d) => d.id === activeId) || parsed.dashboards[0];

        setWidgets(activeDashboard.widgets || []);
        setLayout(activeDashboard.layout || []);
      }
    } catch (err) {
      console.error('Failed to load dashboards from localStorage', err);
    }
  }, []);

  /* ---------- SAVE DASHBOARDS TO LOCAL STORAGE ---------- */

  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          dashboards,
          activeDashboardId,
        }),
      );
    } catch (err) {
      console.error('Failed to save dashboards to localStorage', err);
    }
  }, [dashboards, activeDashboardId]);

  /* ---------- UPDATE GRID COLUMN WIDTH (FOR BACKGROUND LINES) ---------- */

  useEffect(() => {
    const updateColWidth = () => {
      if (!layoutRef.current) return;
      const width = layoutRef.current.offsetWidth;
      if (!width) return;

      const colWidth = width / 12; // cols = 12
      document.documentElement.style.setProperty('--col-width', `${colWidth}px`);
    };

    updateColWidth();
    window.addEventListener('resize', updateColWidth);
    return () => window.removeEventListener('resize', updateColWidth);
  }, []);

  /* ---------- HELPERS ---------- */

  const getActiveDashboard = (): DashboardData | undefined => {
    if (!dashboards.length) return undefined;
    const found = dashboards.find((d) => d.id === activeDashboardId);
    return found ?? dashboards[0];
  };

  /* ---------- HANDLERS ---------- */

  const handleAddWidget = (definition: WidgetDefinition) => {
    const id = generateId();

    const minW = definition.minW ?? 2;
    const minH = definition.minH ?? 3;

    const nextY = layout.length > 0 ? Math.max(...layout.map((l) => l.y + l.h)) : 0;

    const newLayoutItem: RGLLayout = {
      i: id,
      x: 0,
      y: nextY,
      w: Math.max(definition.defaultW, minW),
      h: Math.max(definition.defaultH, minH),
      minW,
      minH,
    };

    setWidgets((prev) => [...prev, { id, type: definition.type }]);
    setLayout((prev) => [...prev, newLayoutItem]);
  };

  const handleRemoveWidget = (id: string) => {
    setWidgets((prev) => prev.filter((w) => w.id !== id));
    setLayout((prev) => prev.filter((l) => l.i !== id));
  };

  const handleClear = () => {
    setWidgets([]);
    setLayout([]);
  };

  const handleLayoutChange = (newLayout: RGLLayout[]) => {
    setLayout(newLayout);
  };

  const toggleEdit = () => {
    setIsEditing((prev) => !prev);
  };

  const handleDashboardTabChange = (key: string) => {
    setActiveDashboardId(key);
    const dash = dashboards.find((d) => d.id === key);
    if (dash) {
      setWidgets(dash.widgets || []);
      setLayout(dash.layout || []);
    }
  };

  /* ---------- SAVE DASHBOARD (NAME → TAB) ---------- */

  const openSaveModal = () => {
    const active = getActiveDashboard();
    setSaveName(active?.name ?? '');
    setIsSaveModalOpen(true);
  };

  const handleConfirmSaveDashboard = () => {
    const trimmed = saveName.trim();
    if (!trimmed) return;

    const active = getActiveDashboard();

    // No dashboards yet → create first one
    if (!active && dashboards.length === 0) {
      const newId = generateId();
      const newDashboard: DashboardData = {
        id: newId,
        name: trimmed,
        widgets,
        layout,
        createdAt: new Date().toISOString(),
      };
      setDashboards([newDashboard]);
      setActiveDashboardId(newId);
      setIsSaveModalOpen(false);
      return;
    }

    // Check if a dashboard with this name already exists
    const existing = dashboards.find((d) => d.name === trimmed);

    if (existing) {
      // Update existing tab (same name)
      const updated = dashboards.map((d) =>
        d.name === trimmed
          ? {
              ...d,
              widgets,
              layout,
            }
          : d,
      );
      setDashboards(updated);
      setActiveDashboardId(existing.id);
    } else {
      // Create a new tab
      const newId = generateId();
      const newDashboard: DashboardData = {
        id: newId,
        name: trimmed,
        widgets,
        layout,
        createdAt: new Date().toISOString(),
      };
      setDashboards((prev) => [...prev, newDashboard]);
      setActiveDashboardId(newId);
    }

    setIsSaveModalOpen(false);
  };

  const activeDashboard = getActiveDashboard();

  /* ---------- RENDER ---------- */

  return (
    <Layout
      className="dashboard-shell"
      style={{
        height: '100vh',
        background: `radial-gradient(circle at top, ${token.colorPrimaryBg} 0, ${token.colorBgLayout} 60%)`,
      }}
    >
      <Content
        style={{
          padding: 24,
          overflow: 'auto',
        }}
      >
        <Card
          className="dashboard-toolbar-card"
          bordered={false}
          style={{
            marginBottom: 16,
            boxShadow: token.boxShadowSecondary,
            borderRadius: 16,
          }}
          bodyStyle={{ padding: 16 }}
        >
          <Space align="center" style={{ width: '100%', justifyContent: 'space-between' }}>
            <Space align="center">
              <div className="dashboard-toolbar-icon">
                <LayoutOutlined />
              </div>
              <div>
                <Title level={4} style={{ margin: 0 }}>
                  Dashboard Builder
                </Title>
                <Text type="secondary">
                  Design and organize your custom widgets for each dashboard.
                </Text>
              </div>
            </Space>

            <Space size="middle" align="center">
              {activeDashboard && (
                <Tag color="blue" style={{ borderRadius: 999 }}>
                  <Text style={{ marginRight: 4 }}>Active:</Text>
                  <Text strong>{activeDashboard.name}</Text>
                </Tag>
              )}

              <Tag color={isEditing ? 'gold' : 'default'} style={{ borderRadius: 999 }}>
                {isEditing ? 'Edit mode' : 'View mode'}
              </Tag>

              <Space>
                <Tooltip title={isEditing ? 'Finish editing' : 'Change layout'}>
                  <Button
                    type={isEditing ? 'primary' : 'default'}
                    icon={isEditing ? <CheckOutlined /> : <EditOutlined />}
                    onClick={toggleEdit}
                  >
                    {isEditing ? 'Done' : 'Edit layout'}
                  </Button>
                </Tooltip>

                {isEditing && (
                  <>
                    <Tooltip title="Save current layout as dashboard (or update existing)">
                      <Button icon={<SaveOutlined />} onClick={openSaveModal}>
                        Save
                      </Button>
                    </Tooltip>

                    <Tooltip title="Clear all widgets from current dashboard">
                      <Button onClick={handleClear}>Clear</Button>
                    </Tooltip>

                    <Tooltip title="Add widgets to the canvas">
                      <Button
                        type="primary"
                        icon={<PlusOutlined />}
                        onClick={() => setDrawerOpen(true)}
                      >
                        Add Widget
                      </Button>
                    </Tooltip>
                  </>
                )}
              </Space>
            </Space>
          </Space>

          {dashboards.length > 0 && (
            <>
              <Divider style={{ margin: '12px 0' }} />
              <Tabs
                className="dashboard-tabs"
                type="card"
                activeKey={activeDashboardId ?? undefined}
                onChange={handleDashboardTabChange}
                items={dashboards.map((d) => ({
                  key: d.id,
                  label: (
                    <Space size={6}>
                      <LayoutOutlined />
                      <span>{d.name || 'Untitled'}</span>
                    </Space>
                  ),
                }))}
              />
            </>
          )}
        </Card>

        {/* GRID / DROP AREA */}
        <Card
          className="dashboard-grid-card"
          style={{
            borderRadius: 16,
            boxShadow: token.boxShadowTertiary,
          }}
          bodyStyle={{ padding: 12 }}
        >
          <div
            ref={layoutRef}
            className="dashboard-grid-outer"
            style={{
              padding: 8,
              borderRadius: 12,
              minHeight: 'calc(100vh - 220px)',
              backgroundColor: token.colorBgContainer,
              border: `1px dashed ${token.colorBorderSecondary}`,
            }}
          >
            <ReactGridLayout
              className={'dashboard-grid-layout' + (isEditing ? ' editing' : '')}
              layout={layout}
              cols={12}
              rowHeight={30}
              margin={[8, 8]}
              onLayoutChange={handleLayoutChange}
              compactType="vertical"
              isDraggable={isEditing}
              isResizable={isEditing}
              draggableCancel=".widget-delete-btn"
              resizeHandles={['s', 'e', 'n', 'w', 'se', 'sw', 'ne', 'nw']}
            >
              {widgets.map((widget) => {
                const def = getWidgetDefinition(widget.type);
                const WidgetComponent = getWidgetComponentByType(widget.type);
                if (!WidgetComponent) return null;

                return (
                  <div key={widget.id}>
                    <WidgetCard
                      title={def?.title ?? widget.type}
                      onRemove={() => handleRemoveWidget(widget.id)}
                      isEditing={isEditing}
                    >
                      <WidgetComponent />
                    </WidgetCard>
                  </div>
                );
              })}
            </ReactGridLayout>

            {widgets.length === 0 && !activeDashboard && (
              <div className="dashboard-empty-state">
                <Title level={5}>No widgets yet</Title>
                <Text type="secondary">
                  Click <b>Edit layout</b>, then <b>Add Widget</b> and <b>Save</b> to create your
                  first dashboard tab.
                </Text>
              </div>
            )}

            {widgets.length === 0 && activeDashboard && (
              <div className="dashboard-empty-state">
                <Title level={5}>This dashboard is empty</Title>
                <Text type="secondary">
                  Click <b>Edit layout</b> and <b>Add Widget</b> to start filling it.
                </Text>
              </div>
            )}
          </div>
        </Card>
      </Content>

      {/* RIGHT DRAWER – WIDGET LIST */}
      <Drawer
        title={
          <Space>
            <AppstoreOutlined />
            <span>Widget Library</span>
          </Space>
        }
        placement="right"
        width={360}
        onClose={() => setDrawerOpen(false)}
        open={drawerOpen}
      >
        <Text type="secondary">
          Drag & resize widgets on the canvas. You can save different layouts as separate
          dashboards.
        </Text>
        <Divider />
        <List
          itemLayout="vertical"
          dataSource={widgetDefinitions}
          renderItem={(item) => (
            <List.Item
              key={item.type}
              actions={
                isEditing
                  ? [
                      <Button
                        type="link"
                        key="add"
                        icon={<PlusOutlined />}
                        onClick={() => handleAddWidget(item)}
                      >
                        Add
                      </Button>,
                    ]
                  : []
              }
            >
              <List.Item.Meta
                title={item.title}
                description={
                  <>
                    <Text type="secondary">{item.description}</Text>
                    <br />
                    <Text type="secondary">
                      Default size: {item.defaultW} × {item.defaultH}
                    </Text>
                  </>
                }
              />
            </List.Item>
          )}
        />
      </Drawer>

      {/* SAVE DASHBOARD MODAL */}
      <Modal
        title="Save dashboard"
        open={isSaveModalOpen}
        onCancel={() => setIsSaveModalOpen(false)}
        onOk={handleConfirmSaveDashboard}
        okButtonProps={{ disabled: !saveName.trim() }}
      >
        <Space direction="vertical" style={{ width: '100%' }}>
          <Input
            placeholder="Dashboard name"
            value={saveName}
            onChange={(e) => setSaveName(e.target.value)}
          />
          <Text type="secondary" style={{ fontSize: 12 }}>
            If a dashboard with this name exists, it will be updated. Otherwise, a new tab will be
            created.
          </Text>
        </Space>
      </Modal>
    </Layout>
  );
};

export default DashboardBuilder;
