export default function SettingsGeneral() {
  return <div style={{ padding: 24 }}>Settings — General</div>;
}
