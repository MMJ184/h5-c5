export default function Home() {
  return <div style={{ padding: 24 }}>Doctor page</div>;
}
